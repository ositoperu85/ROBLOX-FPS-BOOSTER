package com.robloxfpsbooster

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private val red = Color.rgb(255, 55, 65)
    private val bg = Color.rgb(15, 15, 18)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildScreen()
    }

    private fun buildScreen() {
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(28, 42, 28, 28)
            setBackgroundColor(bg)
        }

        val title = TextView(this).apply {
            text = "ROBLOX FPS BOOSTER"
            textSize = 24f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
        }
        val subtitle = TextView(this).apply {
            text = "Indicador flotante para Android 8+"
            textSize = 14f
            setTextColor(Color.LTGRAY)
            gravity = Gravity.CENTER
            setPadding(0, 10, 0, 28)
        }

        val note = TextView(this).apply {
            text = "IMPORTANTE\nEsta primera versión muestra los Hz de la pantalla, no los FPS reales de Roblox. Android no permite que una app normal lea directamente los FPS de otro juego. 120 Hz tampoco garantiza 120 FPS."
            textSize = 15f
            setTextColor(Color.WHITE)
            setPadding(16, 16, 16, 16)
            setBackgroundColor(Color.rgb(35, 35, 40))
        }

        val refresh = TextView(this).apply {
            text = "Frecuencia detectada: ${getRefreshRate().toInt()} Hz"
            textSize = 18f
            setTextColor(red)
            gravity = Gravity.CENTER
            setPadding(0, 26, 0, 26)
        }

        val start = makeButton("ACTIVAR MEDIDOR FLOTANTE") {
            if (!Settings.canDrawOverlays(this)) {
                val intent = Intent(
                    Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:$packageName")
                )
                startActivity(intent)
                Toast.makeText(this, "Permite mostrar sobre otras apps y vuelve aquí.", Toast.LENGTH_LONG).show()
            } else {
                startForegroundService(Intent(this, OverlayService::class.java))
                Toast.makeText(this, "Medidor activado. Puedes abrir Roblox.", Toast.LENGTH_SHORT).show()
            }
        }

        val stop = makeButton("DETENER MEDIDOR") {
            stopService(Intent(this, OverlayService::class.java))
        }

        val hint = TextView(this).apply {
            text = "El indicador se puede arrastrar a una esquina. Toca el medidor para ocultarlo."
            textSize = 13f
            setTextColor(Color.LTGRAY)
            gravity = Gravity.CENTER
            setPadding(0, 24, 0, 0)
        }

        layout.addView(title)
        layout.addView(subtitle)
        layout.addView(note)
        layout.addView(refresh)
        layout.addView(start)
        layout.addView(stop)
        layout.addView(hint)
        setContentView(layout)
    }

    private fun getRefreshRate(): Float {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            display?.refreshRate ?: 60f
        } else {
            @Suppress("DEPRECATION")
            windowManager.defaultDisplay.refreshRate
        }
    }

    private fun makeButton(label: String, action: () -> Unit): Button {
        return Button(this).apply {
            text = label
            setTextColor(Color.WHITE)
            setBackgroundColor(red)
            isAllCaps = false
            textSize = 14f
            setOnClickListener { action() }
            val params = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
            params.topMargin = 14
            layoutParams = params
        }
    }
}
